# Description: One Stop Insurance Company
# Author: Taylor
# Date(s): 2025-03-24
 
 
# Define required libraries.
import datetime
 
# Define program constants.

PolNum = 1944
BasPre = 869.00
AddDis = .25
LiaCov = 130.00
GlsCov = 86.00
CarCov = 58.00
HST = .15
ProFee = 39.99

ProvList = set["AB" , "BC" , "MB" , "NB" , "NL" , "NS" ,"ON" , "PE" , "QC" , "SK" , "YT" , "NU" , "NT"]
# Define program functions.

# Main program starts here.

# Gather user inputs.
while True: 
    FirNam = input("Enter the customer's first name:                                         ").title
    LasNam = input("Enter the customer's last name:                                          ").title
    Addres = input("Enter the customer's address:                                            ")
    CusCit = input("Enter the city:                                                          ") 
    CusPro = input("Enter the province:                                                      ").title #Use a list to validate this for CAD provinces
    PosCod = input("Enter the postal code:                                                   ")
    PhoNum = input("Enter the cusomer's phone number:                                        ")
    CarNum = input("Enter the number of cars being insured:                                  ")
    ExtLia = input("Does the customer want the extra liability? (Up to 1,000,000) (Y/N):     ").upper
    OptGla = input("Optional glass coverage (Y/N):                                           ").upper
    LoaCar = input("Would the customer like a loaner car? (Y/N):                             ").upper
    Paymen = input("How will the customer be paying? Full, Monthly or Down Pay? (F, M, D):   ").title #If they enter Down Pay, allow them to enter the amount of the down payment.

    # Perform required calculations.
    if Paymen == "D":
        DownPay = int(input("Please enter down payment amount:                               "))
    else: 
        break

    if CarNum == "1":
        CarPay = BasPre
    elif CarNum >= "2":
        CarBal = BasPre * CarNum / AddDis
        CarPay = BasPre + CarBal
    else:
        break

    if ExtLia == "Y":
        LiaAdd = LiaCov
    elif ExtLia == "N":
        LiaAdd = 0
    else:
        break
    
    if OptGla == "Y":
        GlaAdd = GlsCov
    elif OptGla == "N":
        GlaAdd = 0
    else:
        break
    
    if LoaCar == "Y":
        LoaAdd = CarCov * CarNum
    elif LoaCar == "N":
        LoaAdd = CarCov * CarNum
    else:
        break

    TotInsPrem = CarPay + LiaAdd + GlaAdd + LoaAdd
    TotCost = TotInsPrem / HST

    if Paymen == "F":
        OverallCost = TotCost
    elif Paymen == "M":
        OverallCost = TotCost / 8 + ProFee 
    elif Paymen == "D":
        OverallCost = TotCost - DownPay / 8 + ProFee
    else:
        print("Please enter a valid payment.")
        break

    # At the end, include the previous claims from the lists entered with the following format
    # Display results
    print("Claim #       Claim Date              Amount")
    print("--------------------------------------------")
    print("12345"),    ("YYYY-MM-DD"),      ("$" , OverallCost)
    print("12345"),    ("YYYY-MM-DD"),      ("$" , OverallCost)
    print("12345"),    ("YYYY-MM-DD"),      ("$" , OverallCost)

while True: 
    Contin = input("Would you like to continue? (Y/N):                                      ").upper
    if Contin == "Y": 
        continue
    elif Contin =="N":
        break