// Description: St John's Marina
// Author: Taylor
// Date(s): 2025-03-25
 
// Define program constants.
const EVE_NUM = 80.00
const ODD_NUM = 120.00 //Site number
const ALT_MEM = 5.00 //$5 per extra person
// These three give the site charges

const WEK_CLN = 50.00 //Weekly cleaning charge
const VID_SUR = 35.00 //Video surveillance per month
// These two give the extra charges

const TAX = .15
// Subtotal = site charge + extra charges, Taxes are 15% of subtotal, monthly charge is subtotal plus taxes

const STAN_MEM = 75.00
const EXEC_MEM = 150.00
// Total monthly charge and total monthly dues are added together to give the Total Monthly Fees

const PROC_FEE = 59.00 //Divided by 12 for yearly fees, multiply the total monthly fees by 12 for this
const CANC_FEE = .60   // 60% of yearly site charges

// Gather user input
let SitNum =    prompt("Enter the customer's site number (1-100):                                            " , 100);
let CusNam =    prompt("Enter the customer's name:                                                           ");
let CusStr =    prompt("Enter the customer's street address:                                                 ");
let CusCit =    prompt("Enter the customer's city:                                                           ");
let CusProv =   prompt("Enter the customer's province:                                                       ");
let CusPos =    prompt("Enter the customer's postal code (X1X1X1):                                           ");
let CusPho =    prompt("Enter the customer's phone number (XXX-XXX-XXXX):                                    ");
let CusCel =    prompt("Enter the customer's cell number (XXX-XXX-XXXX):                                     ");
let CusMem =    prompt("Enter the customer's membership type (S/E):                                          ").toUpperCase;
let CusAlt =    prompt("Enter the number of alternate members:                                               ");
let WeekClean = prompt("Will the site have weekly cleaning? (Y/N):                                           ").toUpperCase;
let MonSurv =   prompt("Will the site have monthly surveillance? (Y/N):                                      ").toUpperCase;

// Perform program calculations and generate results
if (SitNum % 2 == 0) {
    SitVal = EVE_NUM
} else {
    SitVal = ODD_NUM
}

if (CusMem = "S") {
    CusMem = STAN_MEM 
} else if (CusMem = "E") {
    CusMem = EXEC_MEM
}

if (WeekClean = "Y") {
    Clean = WEK_CLN
} else if (WeekClean = "N") {
    Clean = 0
}

if (MonSurv = "Y") {
    Surveil = VID_SUR
} else if (MonSurv = "N") {
    Surveil = 0
}

AlterMems = CusAlt * 5
SitCharg = SitVal + AlterMems //Need to sort by even or odd values
ExtraCharg = Clean + Surveil //Extra charges are the weekly cleaning plus surveillance
SubTot = SitCharg + ExtraCharg
Taxes = TAX * SubTot
MonCharg = SubTot + Taxes
//Total Monthly Charges and Total Monthly Dues to get Total Monthly Fees

MonDue = SitVal
TotMonFee = MonCharg + MonDue
TotYear = TotMonFee * 12
TotMonPay = TotYear + PROC_FEE % 12
CanFee = TotYear % CANC_FEE
// Prepare the receipt for the customer